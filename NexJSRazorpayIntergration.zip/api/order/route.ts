
import { razorpay } from "@src/lib/razorpay";
import { NextResponse } from "next/server";

export async function POST(req: Request) {
    try {
        const { amount } = await req.json();

        const order = await razorpay.orders.create({
            amount: amount * 100,
            currency: "INR",
            receipt: "receipt_" + Date.now(),
        });

        return NextResponse.json({ order });
    } catch (error: any) {
        return NextResponse.json({ error: error.message }, { status: 500 });
    }
}
