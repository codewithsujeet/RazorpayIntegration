import { NextResponse } from "next/server";
import CryptoJS from "crypto-js";
import { RazorpayConfig } from "shared/src/config/apiUrl";

export async function POST(req: Request) {
    try {
        const { razorpay_order_id, razorpay_payment_id, razorpay_signature } =
            await req.json();
        const sign = `${razorpay_order_id}|${razorpay_payment_id}`;
        const expectedSign = CryptoJS.HmacSHA256(
            sign,
            RazorpayConfig.SECRET
        ).toString(CryptoJS.enc.Hex);

        if (expectedSign === razorpay_signature) {
            return NextResponse.json({ success: true });
        } else {
            return NextResponse.json({ success: false });
        }
    } catch (error: any) {
        return NextResponse.json({ error: error.message }, { status: 500 });
    }
}
