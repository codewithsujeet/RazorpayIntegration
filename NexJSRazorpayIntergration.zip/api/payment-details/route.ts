
import { NextResponse } from "next/server";
import { razorpay } from "@src/lib/razorpay";

export async function POST(req: Request) {
    try {
        const { payment_id } = await req.json();

        const paymentDetails = await razorpay.payments.fetch(payment_id);

        return NextResponse.json({
            method: paymentDetails?.method,
            card_type: paymentDetails?.card_type,
            upi_vpa: paymentDetails?.vpa,
            wallet: paymentDetails?.wallet,
            bank: paymentDetails?.bank,
            email: paymentDetails?.email,
            contact: paymentDetails?.contact,
            raw: paymentDetails,
        });
    } catch (error: any) {
        return NextResponse.json({ error: error?.message }, { status: 500 });
    }
}
